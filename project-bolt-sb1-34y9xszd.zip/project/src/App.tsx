import { useEffect, useState } from 'react';
import { StoreProvider, useStore } from './lib/store';
import BottomNav, { Tab } from './components/BottomNav';
import { SplashScreen, LoginScreen } from './screens/Auth';
import HomeScreen from './screens/Home';
import { AddTransactionScreen, HistoryScreen } from './screens/Transactions';
import { ForecastScreen, CalendarScreen } from './screens/Forecast';
import { RiskScreen, RecommendationsScreen, AlertsScreen } from './screens/Insights';
import { ReportsScreen, ProfileScreen, SettingsScreen } from './screens/More';

function Shell() {
  const { session, loading, profile } = useStore();
  const [splashDone, setSplashDone] = useState(() => sessionStorage.getItem('ruralcash-splash') === '1');
  const [tab, setTab] = useState<Tab>('home');
  const [subScreen, setSubScreen] = useState<'none' | 'history' | 'calendar' | 'risk' | 'recommendations' | 'reports' | 'settings'>('none');

  // Apply dark mode
  useEffect(() => {
    if (profile?.dark_mode) document.documentElement.classList.add('dark');
    else document.documentElement.classList.remove('dark');
  }, [profile?.dark_mode]);

  if (!splashDone) {
    return <SplashScreen onDone={() => { sessionStorage.setItem('ruralcash-splash', '1'); setSplashDone(true); }} />;
  }

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-50 dark:bg-slate-900">
        <div className="w-6 h-6 border-2 border-emerald-300 border-t-emerald-600 rounded-full animate-spin" />
      </div>
    );
  }

  if (!session) {
    return <LoginScreen />;
  }

  const renderMain = () => {
    if (subScreen === 'history') return <HistoryScreen />;
    if (subScreen === 'calendar') return <CalendarScreen />;
    if (subScreen === 'risk') return <RiskScreen />;
    if (subScreen === 'recommendations') return <RecommendationsScreen />;
    if (subScreen === 'reports') return <ReportsScreen />;
    if (subScreen === 'settings') return <SettingsScreen />;
    switch (tab) {
      case 'home': return <HomeScreen onNav={(tt) => {
        if (tt === 'add') setTab('add');
        else if (tt === 'forecast') setTab('forecast');
        else if (tt === 'alerts') setTab('alerts');
        else if (tt === 'profile') setTab('profile');
      }} />;
      case 'add': return <AddTransactionScreen onDone={() => setTab('home')} />;
      case 'forecast': return <ForecastScreen />;
      case 'alerts': return <AlertsScreen />;
      case 'profile': return <ProfileScreen onNav={(tt) => setTab(tt)} />;
      default: return <HomeScreen onNav={() => {}} />;
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-900 flex flex-col max-w-md mx-auto relative shadow-xl">
      {/* Sub-screen top bar */}
      {subScreen !== 'none' && (
        <div className="sticky top-0 z-20 bg-white dark:bg-slate-800 border-b border-slate-200 dark:border-slate-700 px-4 py-3 flex items-center justify-between">
          <button onClick={() => setSubScreen('none')} className="text-sm text-emerald-600 font-medium">← Back</button>
          <h2 className="font-semibold text-slate-800 dark:text-slate-100 capitalize">{subScreen}</h2>
          <span className="w-12" />
        </div>
      )}

      <main className="flex-1 overflow-y-auto">
        {renderMain()}

        {/* Quick links grid shown on home */}
        {tab === 'home' && subScreen === 'none' && (
          <div className="px-4 pb-4">
            <p className="text-sm font-semibold text-slate-700 dark:text-slate-200 mb-2">More</p>
            <div className="grid grid-cols-2 gap-2">
              {[
                { label: 'History', screen: 'history' as const, icon: '📋' },
                { label: 'Calendar', screen: 'calendar' as const, icon: '📅' },
                { label: 'Risk Analysis', screen: 'risk' as const, icon: '⚠️' },
                { label: 'AI Tips', screen: 'recommendations' as const, icon: '💡' },
                { label: 'Reports', screen: 'reports' as const, icon: '📊' },
                { label: 'Settings', screen: 'settings' as const, icon: '⚙️' },
              ].map((q) => (
                <button key={q.label} onClick={() => setSubScreen(q.screen)} className="bg-white dark:bg-slate-800 rounded-xl p-3 text-left border border-slate-100 dark:border-slate-700 hover:shadow-sm transition">
                  <div className="text-xl">{q.icon}</div>
                  <div className="text-xs font-medium text-slate-700 dark:text-slate-200 mt-1">{q.label}</div>
                </button>
              ))}
            </div>
          </div>
        )}
      </main>

      <BottomNav active={tab} onChange={(tt) => { setSubScreen('none'); setTab(tt); }} />
    </div>
  );
}

export default function App() {
  return (
    <StoreProvider>
      <Shell />
    </StoreProvider>
  );
}
