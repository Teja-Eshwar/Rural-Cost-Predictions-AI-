/*
# Create stickies table (realtime collaborative board, single-tenant, no auth)

1. Purpose
- Powers a realtime collaborative sticky-notes board.
- Multiple users (no sign-in required) can create, move, edit, and delete sticky notes.
- Changes are broadcast live to all connected clients via Supabase Realtime.

2. New Tables
- `stickies`
  - `id` (uuid, primary key)
  - `content` (text, the note text, defaults to empty string)
  - `color` (text, the note color, defaults to 'yellow')
  - `x` (integer, x position on the board in px, defaults to 0)
  - `y` (integer, y position on the board in px, defaults to 0)
  - `author` (text, display name of the author, defaults to 'Anonymous')
  - `updated_at` (timestamptz, last modification time, defaults to now())
  - `created_at` (timestamptz, defaults to now())

3. Security
- Enable RLS on `stickies`.
- Allow anon + authenticated full CRUD because the board is intentionally public/shared (no sign-in).
- Four separate policies (select/insert/update/delete), each TO anon, authenticated.

4. Realtime
- Add `stickies` to the `supabase_realtime` publication so clients receive INSERT/UPDATE/DELETE events.
*/

CREATE TABLE IF NOT EXISTS stickies (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  content text NOT NULL DEFAULT '',
  color text NOT NULL DEFAULT 'yellow',
  x integer NOT NULL DEFAULT 0,
  y integer NOT NULL DEFAULT 0,
  author text NOT NULL DEFAULT 'Anonymous',
  updated_at timestamptz NOT NULL DEFAULT now(),
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE stickies ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_stickies" ON stickies;
CREATE POLICY "anon_select_stickies" ON stickies FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_stickies" ON stickies;
CREATE POLICY "anon_insert_stickies" ON stickies FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_stickies" ON stickies;
CREATE POLICY "anon_update_stickies" ON stickies FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_stickies" ON stickies;
CREATE POLICY "anon_delete_stickies" ON stickies FOR DELETE
  TO anon, authenticated USING (true);

-- Enable realtime on the table
ALTER PUBLICATION supabase_realtime ADD TABLE stickies;

-- Index for ordering by created_at
CREATE INDEX IF NOT EXISTS stickies_created_at_idx ON stickies (created_at);
