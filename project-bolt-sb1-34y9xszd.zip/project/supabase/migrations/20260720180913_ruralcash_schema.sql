/*
# RuralCash AI — profiles, transactions, alerts (multi-user, owner-scoped)

1. Purpose
- RuralCash AI is a FinTech app for rural micro-enterprises to track cash flow,
  get AI risk scores, cash-flow forecasts, and recommendations.
- Each user manages their own business profile, transactions, and alerts.

2. New Tables
- `profiles`
  - `id` (uuid, primary key; matches auth.users.id)
  - `business_name` (text, default 'My Business')
  - `owner_name` (text, default '')
  - `business_type` (text, default 'Micro-enterprise')
  - `location` (text, default '')
  - `phone` (text, default '')
  - `language` (text, default 'en') — preferred UI language
  - `dark_mode` (boolean, default false)
  - `notify_enabled` (boolean, default true)
  - `created_at` (timestamptz)

- `transactions`
  - `id` (uuid, primary key)
  - `user_id` (uuid, NOT NULL, DEFAULT auth.uid(), references auth.users ON DELETE CASCADE)
  - `type` (text, 'income' | 'expense')
  - `amount` (numeric(12,2), NOT NULL)
  - `category` (text, NOT NULL) — e.g. Sales, Inventory, Loan, Transport, Salary, Utilities, EMI, Grocery, Business, Miscellaneous
  - `description` (text, default '')
  - `date` (date, NOT NULL, default today)
  - `created_at` (timestamptz)

- `alerts`
  - `id` (uuid, primary key)
  - `user_id` (uuid, NOT NULL, DEFAULT auth.uid(), references auth.users ON DELETE CASCADE)
  - `type` (text) — cash_shortage | high_risk | loan_due | expense_spike | forecast_change
  - `title` (text)
  - `body` (text)
  - `severity` (text) — low | medium | high
  - `read` (boolean, default false)
  - `created_at` (timestamptz)

3. Security
- Enable RLS on all three tables.
- Owner-scoped CRUD on each: only the authenticated owner can SELECT/INSERT/UPDATE/DELETE their rows.
- `user_id` columns default to auth.uid() so inserts that omit it still satisfy WITH CHECK.

4. Indexes
- transactions: (user_id, date) for dashboard queries, (user_id, category) for filters.
- alerts: (user_id, created_at) for notification center.

5. Notes
- profiles.id intentionally mirrors auth.users.id (1:1). Inserted on first sign-up via frontend.
- All numeric money stored as numeric(12,2) to avoid float drift.
*/

CREATE TABLE IF NOT EXISTS profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  business_name text NOT NULL DEFAULT 'My Business',
  owner_name text NOT NULL DEFAULT '',
  business_type text NOT NULL DEFAULT 'Micro-enterprise',
  location text NOT NULL DEFAULT '',
  phone text NOT NULL DEFAULT '',
  language text NOT NULL DEFAULT 'en',
  dark_mode boolean NOT NULL DEFAULT false,
  notify_enabled boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_profile" ON profiles;
CREATE POLICY "select_own_profile" ON profiles FOR SELECT
  TO authenticated USING (auth.uid() = id);

DROP POLICY IF EXISTS "insert_own_profile" ON profiles;
CREATE POLICY "insert_own_profile" ON profiles FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = id);

DROP POLICY IF EXISTS "update_own_profile" ON profiles;
CREATE POLICY "update_own_profile" ON profiles FOR UPDATE
  TO authenticated USING (auth.uid() = id) WITH CHECK (auth.uid() = id);

DROP POLICY IF EXISTS "delete_own_profile" ON profiles;
CREATE POLICY "delete_own_profile" ON profiles FOR DELETE
  TO authenticated USING (auth.uid() = id);

CREATE TABLE IF NOT EXISTS transactions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  type text NOT NULL CHECK (type IN ('income','expense')),
  amount numeric(12,2) NOT NULL CHECK (amount >= 0),
  category text NOT NULL,
  description text NOT NULL DEFAULT '',
  date date NOT NULL DEFAULT CURRENT_DATE,
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE transactions ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_transactions" ON transactions;
CREATE POLICY "select_own_transactions" ON transactions FOR SELECT
  TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "insert_own_transactions" ON transactions;
CREATE POLICY "insert_own_transactions" ON transactions FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "update_own_transactions" ON transactions;
CREATE POLICY "update_own_transactions" ON transactions FOR UPDATE
  TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "delete_own_transactions" ON transactions;
CREATE POLICY "delete_own_transactions" ON transactions FOR DELETE
  TO authenticated USING (auth.uid() = user_id);

CREATE INDEX IF NOT EXISTS transactions_user_date_idx ON transactions (user_id, date);
CREATE INDEX IF NOT EXISTS transactions_user_category_idx ON transactions (user_id, category);

CREATE TABLE IF NOT EXISTS alerts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  type text NOT NULL,
  title text NOT NULL,
  body text NOT NULL DEFAULT '',
  severity text NOT NULL DEFAULT 'medium' CHECK (severity IN ('low','medium','high')),
  read boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE alerts ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_alerts" ON alerts;
CREATE POLICY "select_own_alerts" ON alerts FOR SELECT
  TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "insert_own_alerts" ON alerts;
CREATE POLICY "insert_own_alerts" ON alerts FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "update_own_alerts" ON alerts;
CREATE POLICY "update_own_alerts" ON alerts FOR UPDATE
  TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "delete_own_alerts" ON alerts;
CREATE POLICY "delete_own_alerts" ON alerts FOR DELETE
  TO authenticated USING (auth.uid() = user_id);

CREATE INDEX IF NOT EXISTS alerts_user_created_idx ON alerts (user_id, created_at DESC);
